<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class EvaluationsEntreprisesPerformance extends Model
{
    
}
