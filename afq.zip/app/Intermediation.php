<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Intermediation extends Model
{
    
}
