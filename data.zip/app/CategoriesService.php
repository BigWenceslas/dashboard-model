<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class CategoriesService extends Model
{
    
}
