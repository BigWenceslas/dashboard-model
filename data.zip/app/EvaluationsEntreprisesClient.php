<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class EvaluationsEntreprisesClient extends Model
{
    
}
