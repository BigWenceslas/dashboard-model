<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class FondInvestissement extends Model
{
    
}
