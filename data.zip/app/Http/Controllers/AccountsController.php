<?php

namespace App\Http\Controllers;

use App\Service\ServiceManager;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AccountsController extends Controller
{
    public function validatePasswordRequest()
    {

        return view('');
    }

    public function resetPassword($id)
    {

    }

}