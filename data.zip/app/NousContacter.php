<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class NousContacter extends Model
{
    
}
