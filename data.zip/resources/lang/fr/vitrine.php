<?php

return [

    'lien_pourquoi' => 'Pourquoi Choisir Africkup',
    'besoin' => "Quel<span> sont vos besoins</span>",
    'besoin_description' => "Dites nous et nous nous chargeons du reste",

];
