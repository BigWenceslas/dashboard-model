<?php

return [

    'lien_pourquoi' => 'Pourquoi Choisir Africkup',
    'besoin' => "Quel<span> sont vos besoins</span>",
    'besoin_description' => "Dites nous et nous nous chargeons du reste",
    'titre_ressource' => "Nous<span> avons la ressource",
    'description_ressource' => "Nous nous chargeons de faire toutes les recherches neccessaires pour vous.",
    'titre_choix' => "Vous <span> avez le choix",
    'description_choix' => "Nous vous ferons plusieurs propositions",
    'titre_avis' => "Ils donnent leur avis",
    'titre_application' => "Notre application mobile est disponible sur google play et Apple store.",
    'description_application' => "Retrouvez tous les artisans/entreprises/business camerounais et africains en un seul clic » . Il faudra integrer directement les liens vers appstore et google play.",
    'footer_contact' => "Contact",
    'footer_contact_info' => " Nous sommes situés à Yaoundé, entrée Face Visite Technique Nkolfoulou, Tel : , email : infos@africkup.com",
    'footer_menu_principal' => "Menu principal",
    'footer_a_propos' => "A propos",
    'footer_a_propos_info' => "Notre Cabinet realise vos etudes et vous met en relation avec des personnes et institutions adequates pour atteindre nos objectifs",
    'footer_start' => "Démarrer avec Africkup",
    'footer_connexion' => "Connexion",
    'footer_inscription' => "S'enregistrer",
    'footer_accueil' => "Accueil",
    'footer_service' => "Services",
    'footer_formation' => "Formations",
    'footer_investissement' => "Fond d'investissement",

];
