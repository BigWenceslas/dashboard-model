<div>
		<div class="container position-relative">
			<div class="footer-main bg-white2 primary-font ">
				<div class="row no-gutters">
					<div class="col">
						<div class="footer-links d-flex justify-content-between">
							<div class="footer-left-links">
								<div class="linkcol">
									<h5 class="font-weight-extraBold font-15">contact</h5>
									<div class="menu-company-container"> Nous sommes situés à Yaoundé, entrée Face Visite Technique Nkolfoulou, Tel : , email : infos@africkup.com
										<div class="all-links"> <a href="#" class=""><span class="icon-facebook"></span></a> <a href="#" class=""><span class="icon-twitter"></span></a> <a href="#" class=""><span class="icon-instagram"></span></a> <a href="#" class=""><span class="icon-youtube-play"></span></a> </div>
									</div>
								</div>
								<div class="linkcol">
									<h5 class="font-weight-extraBold font-15">Menu principal</h5>
									<div class="menu-company-container">
										<ul id="menu-company" class="menu">
											<li id="menu-item-1060" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1060"><a href="#">Accueil</a></li>
											<li id="menu-item-1149" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1149"><a href="{{route('apropos.index')}}">Pourquoi choisir Africkup</a></li>
											<li id="menu-item-1063" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1063"><a href="{{route('services.index')}}">Service</a></li>
											<li id="menu-item-1062" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1062"><a href="{{route('formations.index')}}">Formation</a></li>
											<li id="menu-item-778" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-778"><a href="#">Fond d'investissement</a></li>
											<li id="menu-item-778" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-778"><a href="{{route('contactus.index')}}">Contact</a></li>
										</ul>
									</div>
								</div>
								<div class="linkcol">
									<h5 class="font-weight-extraBold font-15">A propos</h5>
									<div class="menu-support-container">
										<div class="social-link mt-auto">Notre Cabinet realise vos etudes et vous met en relation avec des personnes et institutions adequates pour atteindre nos objectifs</div>
									</div>
								</div>
								<div class="text-left"> <img src="assets/uploads/2019/04/PCI_DSS.png" alt=""> </div>
							</div>
							<div class="footer-right-link d-flex flex-column">
								<div class="get-start">
									<h5 class="font-weight-extraBold font-15">Demararer avec africkup</h5> <a href="{{route('register_type')}}" class="sign-up">S'enregistrer</a> <a href="#" class="sign-in">Connexion</a> </div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="footer-bottom "> </div>
</div>